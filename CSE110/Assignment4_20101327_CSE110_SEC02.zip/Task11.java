import java.util.*;
public class Task11{
  public static void main(String[]args){
    Scanner sc=new Scanner(System.in);
    System.out.println("Enter a number");
    int n = sc.nextInt();
    int sum=0,c=1;
    while(c<=n)
    {
      sum=sum+c;
      c=c+2;
    }
    System.out.println(sum);
    
  }
}