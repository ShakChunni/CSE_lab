import java.util.*;
public class Task12{
  public static void main(String[]args){
    Scanner a=new Scanner(System.in);
 System.out.println("How many numbers");
 int n=a.nextInt();
 int pr=1,c=1;
 while(c<=n){
   System.out.println("Enter a number");
   int n1=a.nextInt();
   pr=pr*n1;
   c++;
 
 }
 System.out.println(pr);
 
   
 
  }
}