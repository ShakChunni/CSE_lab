import java.util.*;
public class Task13{
  public static void main(String []args){
    Scanner goat = new Scanner(System.in);
    int sum = 0;
    int c = 1;
    while(c < 20){
      
      System.out.println("Enter a number");
      int n1 = goat.nextInt();
      sum = sum + n1;
      c++;
      System.out.println(sum);
    }

  
  
  }

}
