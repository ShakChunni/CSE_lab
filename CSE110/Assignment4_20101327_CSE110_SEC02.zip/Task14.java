public class Task14{
  public static void main(String []args){
    int n1 = 1;
    int j = 0;
    int c = 1;
    while(c <= 1600){
      System.out.println(c);
      j = c + n1;
      c = n1;
      n1 = j;
    }
  }
}