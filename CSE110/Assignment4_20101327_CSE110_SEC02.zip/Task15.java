import java.util.*;
public class Task15{
  public static void main(String[]args){
    Scanner sc= new Scanner(System.in);
    int n = sc.nextInt();
    int c=1,result=1;
    while(c<=n)
    {
      result=result*10;
      c++;
    }
    System.out.println(result);
    
    
  }
}