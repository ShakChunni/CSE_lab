import java.util.*;
public class Task16{
  public static void main(String[]args){
    Scanner h = new Scanner(System.in);
    System.out.println("Enter a number");
    int n = h.nextInt();
    int digit =0;
    while(n>0)
    {
      n=n/10;
      digit++;
    
    }
    System.out.println(digit);
    
  
  
  }
    


}