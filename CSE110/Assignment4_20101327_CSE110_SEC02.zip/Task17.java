import java.util.*;
public class Task17{
  public static void main(String[]args){
    Scanner h = new Scanner(System.in);
    System.out.println("Enter a number");
    int n = h.nextInt();
    int r;
    while(n!=0)
    {
      r=n%10;
      System.out.println(r);
      n=n/10;
      
    
    }
    
  }
}
