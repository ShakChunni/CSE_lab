import java.util.*;
public class Task18{
  public static void main(String[]args){
    Scanner sc= new Scanner(System.in);
    System.out.println("Enter a number");
    int n=sc.nextInt();
    int n1=n,digit=0,p=1;
    while(n>0){
      n=n/10;
      digit++;
    
    }
    digit=digit-1;
    int d=1,c=1;
    while(c<=digit){
      d=d*10;
      c++;
    
    
    }
      
    
    while(p!=0){
      p=n1/d;
      System.out.println(p);
      n1=n1%d;
      d=d/10;
    
    }
    
   
  
  
  }


}