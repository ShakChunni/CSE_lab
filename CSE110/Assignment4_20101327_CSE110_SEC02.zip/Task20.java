import java.util.*;
public class Task20{
  public static void main(String[]args){
    Scanner s = new Scanner(System.in);
    int primeC=0,perC=0;
    System.out.println("First number of the range?");
    int n1 = s.nextInt();
    System.out.println("Last number of the range?");
    int n2 = s.nextInt();
    int n3=n1,n5=n1;
    while(n1<=n2){
      int count=0,sum=0,div1=1,div2=1;
      while(div1<=n1){
        if(n1%div1==0)  
          count++;
        div1++;
      }
      while(div2<n1){
        if(n1%div2==0)  
          sum+=div2;
        div2++;
      }
      
      if(count==2)
        primeC++;
      if(sum==n1)
        perC++;
      
      n1++;
    }
    System.out.println("Between "+n3+" and "+n2+",");
    System.out.println("Found "+primeC+" prime number(s)");
    System.out.println("Found "+perC+" perfect number(s).");
    
    System.out.print("Prime numbers: ");
    
    while(n3<=n2){
      int count=0,div=1;
      while(div<=n3){
        if(n3%div==0)  
          count++;
        div++;
      }
      
      if(count==2)
        System.out.print(n3+", ");
      n3++;
    }
    System.out.println("");
    
    System.out.print("Perfect numbers: ");
    while(n5<=n2){
      int sum=0,div=1;
      while(div<n5){
        if(n5%div==0)  
          sum+=div;
        div++;
      }
      if(sum==n5)
        System.out.print(n5+", ");
      n5++;
    }
  }
  
  
  
} 


