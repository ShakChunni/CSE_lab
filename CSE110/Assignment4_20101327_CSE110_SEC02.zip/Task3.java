import java.util.*;
public class Task3{
  public static void main(String[]args){
    Scanner goat = new Scanner(System.in);
    System.out.println("What's the value of n of the series?");
    int n1 = goat.nextInt();
    double s=0,c=1;
    while(c<=n1)
    {
      s=s+Math.pow(-1,c+1)*c*c;
      c++;
      
    }
    System.out.println((int)s);
    
    
  }
}