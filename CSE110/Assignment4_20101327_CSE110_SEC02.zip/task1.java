import java.util.Scanner;
public class task1
{
  public static void main(String[] args)
  {
    Scanner goat;
    goat = new Scanner(System.in);
    System.out.println("Enter the name of your favourite car:  ");
    String s = goat.nextLine();
    System.out.println("Enter a number");
    int n1 = goat.nextInt();
    int n2 = 1;
    while(n2 < n1)
    {
      System.out.println(s);
      n2++;
    }
       
    
    
  
  
  }

}