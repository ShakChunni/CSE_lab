import java.util.Scanner;
public class task10{
public static void main(String []args)
  {
  Scanner goat = new Scanner(System.in);
  System.out.println("Give a number");
  int n1 = goat.nextInt();
  int sum = 0;
  int c = 1;
  while(7*c <= n1){
    sum = sum + 7*c;
    c++;}
  System.out.println(sum);
  
  
}
}
  