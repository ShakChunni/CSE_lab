import java.util.Scanner;
public class task2{
public static void main(String []args)
  {
  Scanner goat;
  goat = new Scanner(System.in);
  int n1 = 11;
  while(n1 <= 50){
    System.out.println(n1);
    n1 = n1 + 2;}
    
  
  
  
  
  }

}