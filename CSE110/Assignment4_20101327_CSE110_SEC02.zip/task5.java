import java.util.Scanner;
public class task5{
public static void main(String []args)
  {
  Scanner goat;
  goat = new Scanner(System.in);
  int n1 = 1;
  int s = 0;
  int c = 0;
  while(n1 <= 10){
    
    System.out.println("Enter a number");
      int n2 = goat.nextInt();
    if(n2 % 4 == 0){
      c++;
      s = s + n2;
      }
    n1++;
  }
  System.out.println("Sum = " + s);
  System.out.println("Average = " + (s / c));
  
}
}