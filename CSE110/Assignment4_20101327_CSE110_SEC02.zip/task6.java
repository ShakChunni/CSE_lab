import java.util.Scanner;
public class task6{
public static void main(String []args)
  {
  Scanner goat;
  goat = new Scanner(System.in);
  System.out.println("Enter a number ");
  int n1 = goat.nextInt();
  int min = n1;
  int c = 1;
  int x = 0;
  double sum = 0;
  while(c <= 4){
    System.out.println("Enter a number ");
    int n2 = goat.nextInt();
    c++;
    if(n2 < min){
      min = n2;}
    
  if(n2 % 2 ==0){
    x++;
    sum = sum + n2;
  }
  }
    
    System.out.println("Minimum " + min);
    System.out.println("Average " + (sum / x));
    
}
}