import java.util.Scanner;
public class task8{
public static void main(String []args)
  {
  int c = 1;
  int limit = 600;
  int sum = 0;
  while (c <= limit){
    if (c % 7 == 0)
      sum = sum + c;
    else if (c % 9 == 0)
      sum = sum + c;
      
        
      
    c++;
    
    
    }
  System.out.println(sum);
  
  
  }

    
}
